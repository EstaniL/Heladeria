import "./Loading.css"

export const Loading = ()=>{
    return <h2 className="loading-circles">Cargando...</h2> 
}
